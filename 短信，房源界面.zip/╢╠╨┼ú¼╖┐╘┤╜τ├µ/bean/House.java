package org.house.bean;

import java.util.List;

public class House {
    private int hid;
    private String address;
    private String photo;
    private double money;
    private double ared;
    private String type;
    private String layaway;
    private String intro;

    public int getHid() {
        return hid;
    }

    public void setHid(int hid) {
        this.hid = hid;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public double getMoney() {
        return money;
    }

    public void setMoney(double money) {
        this.money = money;
    }

    public double getAred() {
        return ared;
    }

    public void setAred(double ared) {
        this.ared = ared;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLayaway() {
        return layaway;
    }

    public void setLayaway(String layaway) {
        this.layaway = layaway;
    }

    public String getIntro() {
        return intro;
    }

    public void setIntro(String intro) {
        this.intro = intro;
    }
}
