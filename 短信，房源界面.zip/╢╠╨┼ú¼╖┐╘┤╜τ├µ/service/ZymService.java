package org.house.service;

import org.house.bean.House;
import org.house.dao.ZymDao;

import java.sql.SQLException;
import java.util.List;

public class ZymService {
   ZymDao dao=new ZymDao();

    public List<House> getInfoById(String address) throws SQLException {
        List<House> house = dao.getHouseById(address);

        return house;
    }

    public List<House> LoookAll(String page, String city) throws SQLException {
        return dao.LoookAll(page,city);
    }
}
