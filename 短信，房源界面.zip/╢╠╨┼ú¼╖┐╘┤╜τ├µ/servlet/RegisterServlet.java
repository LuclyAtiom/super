package org.house.servlet;

import com.alibaba.fastjson.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
   //注册
   private static final long serialVersionUID = 1L;
        public RegisterServlet() {
            super();
        }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        resp.setContentType("text/html;charset=utf-8");
        resp.setCharacterEncoding("utf-8");

        String mobile = req.getParameter("mobile");//获取手机号
        String verifyCode = req.getParameter("verifyCode");//获取验证码
        String key = req.getParameter("key");//判断是注册还是登陆有参则为注册

        System.out.println(mobile + "------" + verifyCode + "-----" + key);

        JSONObject json = (JSONObject) req.getSession().getAttribute("verifyCode");//获取session中的验证码
        if (json == null) {
            resp.getWriter().write("验证码错误");
        } else if (!json.getString("mobile").equals(mobile)) {
            // renderData(response, "手机号错误");
            resp.getWriter().write("手机号错误");
        } else if (!json.getString("verifyCode").equals(verifyCode)) {
            resp.getWriter().write("验证码错误");
        } /*else if ((System.currentTimeMillis() - json.getLong("createTime")) > 1000 * 60 * 5) {//测试：暂时不判断验证码过期
      response.getWriter().write("验证码已过期");
    } */else {
            System.out.println("登陆成功");
            resp.sendRedirect("/show.html");//跳转展示页面
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }
}
