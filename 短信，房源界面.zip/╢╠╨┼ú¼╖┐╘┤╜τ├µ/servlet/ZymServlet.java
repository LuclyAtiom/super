package org.house.servlet;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.house.bean.House;
import org.house.service.ZymService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/zym")
public class ZymServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);

//        try {
//            resp.setContentType("text/html;charset=utf-8");
//            resp.setCharacterEncoding("utf-8");
//            req.setCharacterEncoding("utf-8");
//
//            String address = req.getParameter("address");
//            System.out.println(address+"111");
////            String type = req.getParameter("type");
////            String money = req.getParameter("money");
//
//            ZymService zym = new ZymService();
//            List<House> House = zym.getInfoById(address);
//
//            ObjectMapper mapper = new ObjectMapper();
//            String jons = mapper.writeValueAsString(House);
//            System.out.println(jons+222);
//            resp.getWriter().write(jons);
//
//
////            System.out.println(type);
////            System.out.println(money);
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            response.setContentType("text/html;charset=utf-8");
            response.setCharacterEncoding("utf-8");
            String page=request.getParameter("page");
            String city=request.getParameter("city");
            System.out.println("servelt:"+city);
            System.out.println(111);
            ZymService zym = new ZymService();
            List<House> houses=zym.LoookAll(page,city);
            System.out.println(houses);
            ObjectMapper mapper = new ObjectMapper();
            String s = mapper.writeValueAsString(houses);
            System.out.println("测试"+s);
            response.getWriter().write(s);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
