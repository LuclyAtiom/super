package org.house.dao;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.house.bean.House;
import org.house.utils.JDBCUtils;

import java.sql.SQLException;
import java.util.List;

public class ZymDao {

    QueryRunner qr = new QueryRunner(JDBCUtils.getDS());

    public List<House> getHouseById(String address) throws SQLException {
        String sql = "SELECT * FROM house WHERE address=?";
        Object[] p = {address};
        List<House> q = qr.query(sql, new BeanListHandler<House>(House.class), p);
        return q;
    }

    public List<House> LoookAll(String page, String city) throws SQLException {
        String sql="";
        System.out.println(page+""+city);
        int a=Integer.valueOf(page);
        a=(a-1)*5;
        if (city.equals("全部")) {
            sql = "SELECT * from house limit ? ,5";
            Object[] params ={a};
            List<House> list = qr.query(sql, new BeanListHandler<House>(House.class), params);
            return list;
        }else {
            sql="SELECT * from house where address=?";
//            sql="SELECT * from house where address=?  limit ? ,5";
            Object[] params ={city,a};
            List<House> list = qr.query(sql, new BeanListHandler<House>(House.class), params);
            return list;
        }
    }
}
