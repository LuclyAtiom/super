
//注意：导航 依赖 element 模块，否则无法进行功能性操作
layui.use(['element','flow'], function(){
    var $ = layui.jquery; //不用额外加载jQuery，flow模块本身是有依赖jQuery的，直接用即可。
    var flow = layui.flow;
    flow.load({
        elem: '#demo' //指定列表容器

        ,done: function(page, next){ //到达临界点（默认滚动触发），触发下一页
            var lis = [];
            //以jQuery的Ajax请求为例，请求下一页数据（注意：page是从2开始返回）
            $.get('/House/zym?page='+page+"&city="+a,function(res){
                //假设你的列表返回在data集合中
                // 假设你的列表返回在data集合中
                //lis.push('<li>'+ res.qw+'</li>');
                layui.each(res, function(index, item){
                    //     lis.push('<a href="Demo1.html"><img height="40%" width="20%" src="'+item.photos+'"></a><font size="30" color="red">地点：</font><input type="text" value="'+item.address+'">房型：<input type="text" value="'+item.type+'">面积：<input type="text" value="'+item.intro+'"><br>');
                    // });
                    lis.push('<a href="Demo1.html"><img height="20%" width="20%" src="'+item.photo+'"></a>' +
                        '地点：<input type="text" value="'+item.address+'">' +
                        '房型：<input type="text" value="'+item.type+'">' +
                        '面积：<input type="text" value="'+item.intro+'">' +
                        '<br>');
                });
                //执行下一页渲染，第二参数为：满足“加载更多”的条件，即后面仍有分页
                //pages为Ajax返回的总页数，只有当前页小于总页数的情况下，才会继续出现加载更多
                next(lis.join(''), page <=page);
            },"json");
        }
    });
});



// 轮播图
layui.use('carousel', function(){
    var carousel = layui.carousel;
    //建造实例
    carousel.render({
        elem: '#test1'
        ,width: '100%' //设置容器宽度的百分比
            ,height:'400px'
        ,arrow: 'always' //始终显示箭头和点击按钮
        //,anim: 'updown' //切换动画方式，可从各个方向滚动
    });
});


//弹出层方法
layer.open({
    title: '明细',
    type: 2,
    content: 'House/sdfgh.html',
    area: screen() < 2 ? ['90%', '80%'] : ['1280px', '720px'],
});
//判断浏览器大小方法
function screen() {
    //获取当前窗口的宽度
    var width = $(window).width();
    if (width > 1200) {
        return 3;   //大屏幕
    } else if (width > 992) {
        return 2;   //中屏幕
    } else if (width > 768) {
        return 1;   //小屏幕
    } else {
        return 0;   //超小屏幕
    }
}
